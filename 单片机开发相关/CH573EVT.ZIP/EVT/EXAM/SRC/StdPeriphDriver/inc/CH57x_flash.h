


#ifndef __CH57x_FLASH_H__
#define __CH57x_FLASH_H__

#ifdef __cplusplus
 extern "C" {
#endif
     
void FLASH_ROM_READ( UINT32 StartAddr, PVOID Buffer, UINT32 len );           /* ��ȡFlash-ROM */


#ifdef __cplusplus
}
#endif

#endif  // __CH57x_FLASH_H__	

